<?php

$authKey = "06e299-164c4ddbf86e-117d6a8ce0db30938ba5";
$language = "es";

?>